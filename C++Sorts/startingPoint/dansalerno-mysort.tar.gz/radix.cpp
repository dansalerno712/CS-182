#include "sorting.hh"

template void Sortings<int, intuival>::radix(int*, unsigned int);

template <class Elem, class Comp>
void Sortings<Elem, Comp>::radix(Elem *arr, unsigned int n)
{

}
